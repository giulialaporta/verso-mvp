# VERSO — Product Requirements Document (PRD)
> Version 1.0 | Target: Lovable AI Builder  
> Audience: Professionisti in job hunting attivo  
> Stack: React + TypeScript + Supabase + Tailwind + shadcn/ui  
> Brand reference: `brand-system.md` (must be loaded alongside this file)

---

## 0. Context for Lovable

This PRD defines the full v1 of **Verso**, an AI-powered recruiting funnel assistant. Build this as a **mobile-first web application** that works flawlessly on both mobile (375px+) and desktop (1280px). All UI must strictly follow the `brand-system.md` file. Dark mode only. No light mode.

The app uses **Supabase** for auth, database, and storage. AI features call a backend edge function that acts as a **provider-agnostic AI gateway** (supporting Claude API and OpenAI, switchable via env variable). All external integrations (LinkedIn, Gmail/Outlook) use OAuth 2.0.

---

## 1. Product Vision

**What is Verso?**  
Verso is the intelligent co-pilot for job seekers. It automatically tailors your CV to each job application, scores your compatibility, tracks every application through a pipeline, and tells you exactly what to learn to become a stronger candidate — without ever making up experience you don't have.

**Core Promise:**  
*The best version of your real self, matched to every opportunity.*

**Monetization Model:** Freemium  
- **Free tier:** 3 AI CV tailorings/month, manual application tracking, basic score.  
- **Pro tier (€12.99/mo or €99/yr):** Unlimited tailorings, email sync, LinkedIn import, course suggestions, shareable CV link, all templates.

---

## 2. User Personas

**Primary: Marco, 31, Product Manager**  
Actively job hunting. Sends 10–20 applications/month. Has a solid CV but knows it reads generic. Frustrated by ATS rejections. Wants to move fast without sacrificing quality. Uses iPhone + MacBook.

**Secondary: Giulia, 27, UX Designer**  
Career switcher. Less experienced, needs to understand where her gaps are and how to close them. Values clarity and actionable feedback. Primarily mobile user.

---

## 3. Tech Stack Decisions

| Layer | Choice | Reason |
|---|---|---|
| Frontend | React + TypeScript + Vite | Lovable default, type safety |
| Styling | Tailwind CSS + shadcn/ui (Verso tokens) | Per brand system |
| Backend | Supabase (Auth, DB, Storage, Edge Functions) | Lovable native, no custom server needed |
| AI Gateway | Supabase Edge Function → Claude API / OpenAI | Multi-provider, key stored in Supabase secrets |
| State | Zustand | Lightweight, no Redux overhead |
| Drag & Drop | @dnd-kit/core | Kanban board |
| Animation | Framer Motion | Page transitions, score bars, sheets |
| Icons | @phosphor-icons/react | Per brand system |
| PDF Export | react-pdf or jspdf + html2canvas | CV export |
| DOCX Export | docx.js | CV export |
| Rich Text | Tiptap | Master CV editor |

---

## 4. Information Architecture

```
/                          → Landing page (logged out)
/login                     → Auth (email + Google OAuth)
/onboarding                → First-run wizard (upload CV, connect accounts)

/app                       → App shell (authenticated)
  /app/home                → Dashboard
  /app/candidature         → Kanban board (all applications)
  /app/candidature/:id     → Application detail
  /app/nuova               → New application wizard
  /app/profilo             → User profile + master CV
  /app/impostazioni        → Settings (integrations, plan, AI provider)
```

**Mobile Navigation:** Bottom tab bar with 5 tabs: Home | Candidature | + (Nuova) | Profilo | Impostazioni

**Desktop Navigation:** Left sidebar (collapsed to icons on narrow desktop, expanded on wide).

---

## 5. Database Schema (Supabase)

```sql
-- Users (extended from Supabase auth.users)
profiles (
  id uuid references auth.users primary key,
  full_name text,
  email text,
  avatar_url text,
  plan text default 'free',          -- 'free' | 'pro'
  ai_provider text default 'claude', -- 'claude' | 'openai'
  linkedin_connected boolean default false,
  gmail_connected boolean default false,
  outlook_connected boolean default false,
  tailoring_count_this_month int default 0,
  created_at timestamptz default now()
)

-- Master CV (one per user, versioned)
master_cvs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  content jsonb,          -- structured CV data (see CV schema below)
  raw_text text,          -- plain text for AI processing
  source text,            -- 'upload' | 'editor' | 'linkedin'
  version int default 1,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
)

-- CV Templates
cv_templates (
  id uuid primary key default gen_random_uuid(),
  name text,
  description text,
  thumbnail_url text,
  structure jsonb,        -- layout/section ordering config
  is_pro boolean default false,
  created_at timestamptz default now()
)

-- Applications (the core entity)
applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  company_name text not null,
  company_logo_url text,
  company_description text,
  company_sector text,
  company_size text,
  role_title text not null,
  role_description text,          -- raw job description text
  role_url text,                  -- original URL scraped
  status text default 'inviata',  -- 'inviata' | 'visualizzata' | 'contattato' | 'follow_up' | 'ko'
  match_score int,                -- 0-100
  tailored_cv_id uuid references tailored_cvs(id),
  template_id uuid references cv_templates(id),
  notes text,
  applied_at timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
)

-- Tailored CVs (generated per application)
tailored_cvs (
  id uuid primary key default gen_random_uuid(),
  application_id uuid references applications(id),
  user_id uuid references profiles(id),
  content jsonb,               -- tailored CV structured data
  diff jsonb,                  -- changes vs master CV
  pdf_url text,                -- Supabase Storage URL
  docx_url text,
  share_token text unique,     -- for shareable link
  ai_provider text,            -- which AI generated this
  created_at timestamptz default now()
)

-- Skill Gap Analysis (per application)
skill_gaps (
  id uuid primary key default gen_random_uuid(),
  application_id uuid references applications(id),
  skill_name text,
  importance text,             -- 'critical' | 'important' | 'nice_to_have'
  user_has boolean default false,
  course_suggestions jsonb,    -- [{title, platform, url, duration_hours}]
  created_at timestamptz default now()
)

-- Application Status History
application_events (
  id uuid primary key default gen_random_uuid(),
  application_id uuid references applications(id),
  event_type text,             -- 'status_change' | 'email_received' | 'note_added' | 'follow_up_sent'
  old_status text,
  new_status text,
  metadata jsonb,
  created_at timestamptz default now()
)

-- Email Threads (synced)
email_threads (
  id uuid primary key default gen_random_uuid(),
  application_id uuid references applications(id),
  user_id uuid references profiles(id),
  thread_id text,              -- external email thread ID
  provider text,               -- 'gmail' | 'outlook'
  subject text,
  last_message_at timestamptz,
  messages jsonb,              -- [{from, body, date}]
  created_at timestamptz default now()
)
```

**CV Content JSON Schema:**
```json
{
  "personal": { "name": "", "email": "", "phone": "", "location": "", "linkedin": "", "website": "" },
  "summary": "",
  "experience": [{ "company": "", "role": "", "start": "", "end": "", "current": false, "bullets": [] }],
  "education": [{ "institution": "", "degree": "", "field": "", "start": "", "end": "" }],
  "skills": { "technical": [], "soft": [], "languages": [] },
  "certifications": [{ "name": "", "issuer": "", "date": "" }],
  "projects": [{ "name": "", "description": "", "url": "" }]
}
```

---

## 6. Feature Specifications

---

### F1 — Onboarding Wizard

**Trigger:** First login after account creation.  
**Steps:** 3-step wizard with progress indicator.

**Step 1: Carica il tuo CV**
- Tab switcher: Upload file | Import da LinkedIn | Editor manuale
- Upload: Accepts PDF, DOCX. File parsed server-side (Supabase edge function extracts text, structures into CV JSON schema). Show upload progress + extraction skeleton.
- LinkedIn: OAuth flow → fetch profile via LinkedIn API → map to CV schema.
- Editor: Skip for now → go directly to empty Tiptap editor (can fill later).
- On completion: Save to `master_cvs` table.

**Step 2: Connetti i tuoi account (opzionale)**
- Gmail OAuth button → scope: `gmail.readonly` (read threads only, no send without permission)
- Outlook OAuth button → scope: `mail.read`
- LinkedIn OAuth button (if not already used in step 1)
- Skip button clearly visible — integrations can be done later in Settings.

**Step 3: Il tuo profilo è pronto**
- Summary card: CV parsed skills cloud, experience years, detected role category.
- CTA: "Aggiungi la tua prima candidatura →"

---

### F2 — New Application Wizard

**Trigger:** FAB button (mobile) or "Nuova candidatura" button (desktop).  
**UI:** Full-screen 4-step wizard with step indicator and back navigation.

**Step 1: L'annuncio**

Two input modes (tab switcher):

*URL Scraping (default):*
- Text input for URL
- "Analizza" button triggers Supabase edge function:
  - Fetches URL content (server-side, no CORS issues)
  - Strips HTML, extracts job description text
  - AI call: extracts company name, role title, structured requirements
- Shows skeleton loader during analysis
- On success: preview card with extracted data (company, role, key requirements)
- User can edit/correct extracted fields

*LinkedIn Import:*
- If LinkedIn connected: Show search field to find the job posting by URL or search
- Fetch via LinkedIn Jobs API (if available) or fallback to URL scraping

**Step 2: Analisi AI**

Triggered automatically after step 1 confirmation.

AI prompt (sent to edge function, executed against selected provider):
```
You are an expert career coach. Given the user's master CV and this job description, provide:
1. Company insights (sector, size estimate, culture signals from description)
2. Skill match: list skills required by the job, mark which ones the user has (true/false)
3. Match score: 0-100 integer
4. Top 3 skills gaps (critical missing skills)
5. Tailoring opportunities: specific experience bullets from the user's CV that should be emphasized or rewritten
Return as structured JSON.
```

UI during analysis:
- 4 skeleton cards loading sequentially with labels: "Analizzo l'azienda..." → "Confronto le competenze..." → "Calcolo il match..." → "Preparo i suggerimenti..."
- Each resolves independently as AI streams response (use streaming)

UI after analysis:
- **Company card:** Logo (fetched via Clearbit API or favicon fallback), name, sector, size, 2-3 culture signals as tags
- **Match Score meter:** Gradient bar (red→yellow→green) animating from 0 to score value over 800ms. Large score number in JetBrains Mono. Label: "Compatibilità con il profilo"
- **Skills breakdown:** Two columns — "Hai già" (green chips) | "Ti mancano" (red chips with importance badge)
- **Tailoring opportunities:** List of 3-5 suggested CV edits, each showing original bullet vs suggested rewrite

**Step 3: Scegli il template**

- Grid/carousel of CV templates (3 columns desktop, horizontal scroll mobile)
- Each template card: thumbnail preview, template name, compatibility note (e.g. "Ottimo per ruoli tech"), Pro badge if premium
- Free users see all templates but Pro ones are locked with upgrade prompt
- Default: Verso Classic (clean, ATS-friendly)
- Selected template: accent border glow

**Step 4: CV generato**

- **Side-by-side diff view** (desktop: two columns | mobile: tab switcher "Originale" / "Tailorizzato")
  - Changed sections highlighted with subtle accent-colored left border
  - Hover/tap on changed section shows tooltip: "Adattato per enfatizzare [skill]"
- **Score badge** (top right of tailored CV preview)
- **Action buttons:**
  - "Scarica PDF" → generates PDF via react-pdf, triggers download
  - "Scarica DOCX" → generates via docx.js
  - "Crea link condivisibile" (Pro only) → generates unique `share_token`, copies URL to clipboard
  - "Salva candidatura" → saves everything to DB, redirects to application detail

---

### F3 — Application Tracker (Kanban Board)

**Route:** `/app/candidature`

**Layout:**
- Desktop: 5-column kanban board, horizontal scroll if needed, fixed column headers
- Mobile: Single column view with status filter tabs at top (pill tabs, horizontal scroll)

**Columns (in order):**
1. INVIATA
2. VISUALIZZATA  
3. CONTATTATO
4. FOLLOW-UP
5. KO

**Application Card contains:**
- Company logo (40px, rounded)
- Role title (DM Sans 500, 15px)
- Company name (muted, 13px)
- Days since application (e.g. "3 giorni fa") in JetBrains Mono
- Match score badge (small, colored by score range)
- Status chip (per brand system color table)

**Interactions:**
- Desktop: Drag & drop cards between columns (dnd-kit). Drop zone highlights with accent border.
- Mobile: Swipe right → advance status. Swipe left → KO. Tap → open detail bottom sheet.
- Click/tap card → navigate to application detail

**Filters & Sort (top bar):**
- Search by company or role
- Filter by status (multi-select)
- Sort: Date applied | Score | Company name

**Empty state per column:**
- Friendly illustration + short message in brand voice. E.g. "Nessuna candidatura in Follow-up. Buon segno o c'è qualcuno a cui scrivere?"

---

### F4 — Application Detail

**Route:** `/app/candidature/:id`  
**Mobile:** Opens as bottom sheet (95% height, draggable handle)  
**Desktop:** Full page

**Sections:**

**Header:**
- Company logo + name + role title
- Status chip (tappable → status change dropdown)
- Match score (compact version)
- Quick actions: Download CV | Open job URL | Archive

**Status Timeline:**
- Horizontal stepper showing all 5 stages
- Completed stages in accent color, current stage pulsing
- Timestamps below each completed stage

**Tabs (desktop) / Accordion sections (mobile):**

*Candidatura:*
- CV tailored preview (scrollable, read-only)
- Download PDF / DOCX buttons
- Shareable link (Pro)

*Azienda:*
- Company card (logo, sector, size, culture signals)
- Key requirements from job description (tag cloud)

*Competenze:*
- Full skill gap analysis
- For each gap: skill name, importance badge, suggested courses list
  - Course card: platform logo (Coursera/Udemy/LinkedIn Learning), course title, duration, "Vai al corso →" link
- "Alza il tuo score" CTA: shows what score would be with each gap closed

*Email:*
- If email connected: threaded email view (read-only) filtered by company domain
- "Scrivi follow-up" button → opens pre-drafted email in modal (AI-generated, user can edit before sending — requires explicit confirmation "Invia email")
- If not connected: "Connetti Gmail/Outlook per vedere le email relative a questa candidatura"

*Note:*
- Freeform textarea for personal notes
- Auto-saved on blur

**Status Change:**
- Tapping status chip opens popover with all 5 status options
- On change: record event in `application_events`, update `updated_at`, animate chip crossfade

---

### F5 — Master CV Profile

**Route:** `/app/profilo`

**Sections:**

**My CV (Tiptap rich text editor):**
- Structured sections: Personal info, Summary, Experience, Education, Skills, Certifications, Projects
- Add/remove/reorder sections
- Each experience entry: company, role, dates, bullet points (each bullet editable independently)
- Auto-save every 30 seconds + on blur
- "Aggiorna CV" button → re-runs skill extraction, updates profile

**Skills Cloud:**
- Interactive tag cloud of all detected skills
- Color coded: technical (blue), soft (gray), languages (yellow)
- Click skill → see which applications required it
- "Aggiungi skill" → text input with autocomplete

**Connections Panel:**
- OAuth connection cards for Gmail, Outlook, LinkedIn
- Each card: service logo, connection status (connected/disconnected), connected account email, disconnect button
- "Connetti" button → triggers OAuth flow

**CV Versions:**
- List of all tailored CVs generated
- Each row: company + role, date, score, download buttons
- "Imposta come CV master" option (overrides master with tailored version)

---

### F6 — AI CV Tailoring Engine (Edge Function)

**Supabase Edge Function:** `POST /functions/v1/ai-tailor`

**Input:**
```json
{
  "master_cv": { ...CV JSON... },
  "job_description": "...",
  "company_info": { "name": "", "sector": "" },
  "provider": "claude" | "openai",
  "task": "analyze" | "tailor" | "score" | "suggest_courses"
}
```

**Provider routing:**
```typescript
if (provider === 'claude') {
  // Use Anthropic SDK, model: claude-opus-4-6
} else {
  // Use OpenAI SDK, model: gpt-4o
}
```

**Tailoring Rules (prompt constraints for AI):**
- NEVER invent experience, certifications, or skills the user doesn't have
- NEVER change dates, company names, or role titles
- MAY reorder bullet points to lead with most relevant experience
- MAY rewrite bullet points to use keywords from job description (while keeping factual accuracy)
- MAY suggest removing sections less relevant to this role
- MAY adjust summary paragraph to align with role requirements
- MUST return structured JSON, not prose

**Course Suggestion Logic:**
- For each identified skill gap, AI suggests 2-3 courses
- Sources: Coursera, LinkedIn Learning, Udemy (hardcoded platform list)
- AI provides: course title, platform, estimated search URL, duration estimate
- Do NOT call external APIs for courses in v1 — AI generates suggestions based on training knowledge

---

### F7 — Freemium & Plan Management

**Free tier limits:**
- 3 AI tailorings per calendar month (tracked in `profiles.tailoring_count_this_month`, reset via cron)
- Max 10 applications in tracker
- 2 CV templates (Verso Classic + Verso Minimal)
- No shareable CV link
- No email sync
- No course suggestions

**Pro tier unlocks:**
- Unlimited tailorings
- Unlimited applications
- All 8+ CV templates
- Shareable CV link with custom slug
- Email sync (Gmail + Outlook)
- Course suggestions
- Priority AI processing

**Upgrade prompts:**
- When free user hits tailoring limit: Modal with usage counter (e.g. "3/3 tailoring usati questo mese") + Pro upgrade CTA
- When free user tries Pro feature: Inline lock icon + "Disponibile con Verso Pro" tooltip → upgrade modal

**Pricing page:** `/pricing` (marketing, not in app shell). Simple 2-column card: Free vs Pro. Annual pricing shown by default with toggle for monthly.

**Payment:** Integrate Stripe via Supabase + Stripe extension. Handle webhook for subscription events → update `profiles.plan`.

---

### F8 — Settings

**Route:** `/app/impostazioni`

**Sections:**

*Account:*
- Edit name, email, avatar
- Change password
- Delete account (with confirmation modal)

*Integrazioni:*
- Same as profile connections panel (Gmail, Outlook, LinkedIn)

*AI Provider:*
- Toggle between Claude (default) and OpenAI
- Only visible if Pro (or always visible as UX choice — decide)
- Explanation tooltip: "Scegli il modello AI per generare i tuoi CV"

*Piano:*
- Current plan badge (Free / Pro)
- Usage stats: tailorings used this month, applications count
- Upgrade CTA (if Free) or manage subscription link (if Pro → Stripe portal)

*Notifiche:*
- Toggle: Email reminders for follow-ups (default: on)
- Toggle: Weekly summary of application pipeline (default: on)

---

## 7. Key User Flows

### Flow A: First tailored application (happy path)
1. User signs up → onboarding wizard → uploads PDF CV
2. Taps "+" → New application wizard
3. Pastes LinkedIn job URL → app scrapes → shows company + job analysis
4. Score: 68%. Mancano: "SQL", "Stakeholder management" (AI output)
5. Selects "Verso Tech" template
6. Reviews diff → one rewritten bullet highlighted
7. Downloads PDF → saves application
8. Application appears in Kanban "INVIATA" column

### Flow B: Status update via email sync
1. Recruiter replies to application email
2. Gmail webhook (or polling) detects new email from company domain
3. Application status auto-updates to "VISUALIZZATA"
4. Push notification (web push): "Novità da Acme Corp su Product Manager role"
5. User opens app → sees updated status chip in Kanban

### Flow C: Follow-up reminder
1. Application in "INVIATA" for 7+ days
2. App surfaces reminder on dashboard: "Sono passati 7 giorni da Acme Corp. Vale la pena scrivere?"
3. User taps "Scrivi follow-up" → AI drafts email based on role + original application date
4. User reviews + sends (Gmail/Outlook OAuth send scope required — ask permission at send time)

### Flow D: Gap closing
1. User opens Application Detail → "Competenze" tab
2. Sees: "SQL — Critico — Mancante"
3. Taps "Vai al corso" → Coursera SQL course link opens
4. User completes course externally → returns to app → manually marks skill as acquired
5. Score recalculates upward (client-side simulation)

---

## 8. Non-Functional Requirements

**Performance:**
- First Contentful Paint < 1.5s on 4G
- AI analysis response: show first partial result within 3s (streaming)
- CV PDF generation: < 5s
- Kanban drag interactions: 60fps

**Security:**
- All AI calls go through Supabase Edge Functions — API keys never exposed to client
- OAuth tokens stored encrypted in Supabase, never in localStorage
- CV content stored in Supabase DB (RLS policies: user can only access own data)
- PDF/DOCX files stored in Supabase Storage with signed URLs (not public)
- Share links use random UUID tokens, not sequential IDs

**Accessibility:**
- WCAG 2.1 AA minimum
- Full keyboard navigation for Kanban
- Screen reader labels on all icon buttons
- Focus visible indicators (accent-colored outline)

**Offline:**
- Application list readable offline (cached in service worker)
- New application wizard requires connection (AI analysis)
- Show offline banner when detected

---

## 9. Error States & Edge Cases

| Scenario | Behavior |
|---|---|
| URL scraping fails (paywall, JS-rendered) | Show error: "Non riesco a leggere questa pagina. Incolla il testo dell'annuncio manualmente." → fallback to paste textarea |
| AI timeout (>15s) | Show retry button + "L'analisi sta richiedendo più del solito. Riprova." |
| LinkedIn OAuth denied | Skip silently, show toast: "Puoi connettere LinkedIn in qualsiasi momento dalle impostazioni." |
| Free tier limit reached | Modal with counter, not hard block — show upgrade CTA prominently |
| CV parse fails (unreadable PDF) | "Non riesco a leggere questo PDF. Prova a caricarlo in DOCX o usa l'editor manuale." |
| Email sync: company domain not matched | Don't auto-update status. Show unlinked emails in separate "Email non associate" section |
| Shareable link accessed (no login) | Public CV preview page: company logo + name redacted for privacy, CV content visible |

---

## 10. Out of Scope for v1

The following are explicitly excluded from v1 to keep scope manageable:

- Native mobile app (iOS/Android) — web app with PWA support is sufficient
- Job search / job discovery (Verso is about applications you initiate, not a job board)
- Multi-user / team features (recruiter persona deferred to v2)
- ATS integration (Greenhouse, Lever, Workday) — tracked manually for now
- Calendar integration (interview scheduling) — v2
- Resume builder from scratch (user must have existing CV) — v2
- Cover letter generator — v2 (referenced in gap analysis UI but not built)
- AI interview prep — v2

---

## 11. MVP Build Order for Lovable

Build in this sequence to have a working demo as fast as possible:

1. **Auth + Supabase setup** — Login/signup with email + Google OAuth. Profiles table. RLS policies.
2. **Onboarding wizard** — CV upload + parsing (PDF text extraction via edge function). Master CV saved.
3. **New application wizard** — URL input + edge function scraping + AI analysis + score display. (Stub the template step with one default template.)
4. **Kanban board** — Applications list with status columns. Manual status changes. Application cards.
5. **Application detail** — Status timeline, CV preview, company info, notes.
6. **CV tailoring + export** — Diff view, PDF export, DOCX export.
7. **Template system** — Multiple templates, template selector carousel.
8. **Skill gap + course suggestions** — Gap list in application detail, course cards.
9. **Profile + master CV editor** — Tiptap editor, skills cloud.
10. **Email integration** — Gmail OAuth, thread display in application detail.
11. **Freemium gates** — Usage limits, upgrade modals, Stripe integration.
12. **Shareable CV link** — Public preview page.
13. **LinkedIn import** — OAuth + profile mapping.
14. **Settings page** — All settings sections.
15. **Polish** — Animations, empty states, error states, PWA manifest.

---

## 12. Brand & Design Reminders for Lovable

> ⚠️ Always load `brand-system.md` alongside this PRD. All design decisions must conform to it.

Key reminders:
- Dark mode only. Background: `#0C0D10`. Never white or light gray backgrounds.
- Primary accent: `#A8FF78` (lime green). Used sparingly — CTAs and scores only.
- Fonts: Syne (headlines), DM Sans (body), JetBrains Mono (numbers/labels/chips).
- No purple gradients. No Inter font. No generic shadcn default theme.
- Mobile bottom tab bar, not hamburger menu.
- Kanban status chips use the exact colors defined in brand system.
- Score bars animate from 0 → value on mount (Framer Motion, 800ms ease-out).
- Cards have `translateY(-2px)` hover lift, not scale transforms.
- Loading states: skeletons only, no spinners.
- Tone: direct, dry, slightly warm. Never enthusiastic corporate speak.

---

*VERSO PRD v1.0 — Ready for Lovable build*  
*Pair with: `brand-system.md`*
